# KSM GLOBAL — ENTRENA CON FE
## Programa Premium de 90 días
**Disciplina · Fe · Propósito**

**Propuesta comercial:** US$25, pago único. Días 1–7 gratuitos; días restantes Premium tras confirmar el pago. Sin renovación automática.

## Fases
- **Fase I (días 1–30):** fundamentos, técnica básica, movilidad y constancia.
- **Fase II (días 31–60):** fuerza general, resistencia, equilibrio y progresión gradual.
- **Fase III (días 61–90):** autonomía, recuperación, evaluación y continuidad.

## Seguridad
Guía general para adultos, no prescripción médica ni plan individual. Ajustar intensidad y volumen. Detenerse ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Ante lesiones o condiciones médicas, consultar a un profesional.

## Banco de ejercicios

### Sentarse y levantarse de una silla
- Dosificación: 2 × 6–10 repeticiones; descanso: 45–60 s.
- Técnica: Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
- Referencia de video por revisar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration

### Flexiones contra la pared
- Dosificación: 2 × 6–10 repeticiones; descanso: 45–60 s.
- Técnica: Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
- Referencia de video por revisar: https://www.youtube.com/results?search_query=wall+push+up+proper+form

### Elevaciones de talones con apoyo
- Dosificación: 2 × 8–12 repeticiones; descanso: 30–45 s.
- Técnica: Sujétate de una silla firme, eleva los talones y baja lentamente.
- Referencia de video por revisar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise

### Bird-dog alternado
- Dosificación: 2 × 5–8 por lado; descanso: 45 s.
- Técnica: En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
- Referencia de video por revisar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form

### Marcha suave en el lugar
- Dosificación: 2 × 45–60 segundos; descanso: 30 s.
- Técnica: Marcha a ritmo cómodo, tronco erguido y apoyo seguro.
- Referencia de video por revisar: https://www.youtube.com/results?search_query=march+in+place+beginner+exercise

### Bisagra de cadera sin carga
- Dosificación: 2 × 8 repeticiones; descanso: 45 s.
- Técnica: Lleva la cadera atrás con rodillas ligeramente flexionadas y espalda neutral.
- Referencia de video por revisar: https://www.youtube.com/results?search_query=bodyweight+hip+hinge+exercise

### Paso lateral controlado
- Dosificación: 2 × 30–45 segundos; descanso: 30 s.
- Técnica: Da pasos laterales cortos y controla el regreso, manteniendo las rodillas alineadas.
- Referencia de video por revisar: https://www.youtube.com/results?search_query=lateral+step+exercise

### Deslizamiento de brazos en pared
- Dosificación: 2 × 8 repeticiones; descanso: 30 s.
- Técnica: Desliza los brazos por la pared dentro de un rango cómodo sin arquear la zona lumbar.
- Referencia de video por revisar: https://www.youtube.com/results?search_query=wall+slide+shoulder+mobility+exercise

### Dead bug básico
- Dosificación: 2 × 5–8 por lado; descanso: 45 s.
- Técnica: Boca arriba, mueve una extremidad a la vez manteniendo control del tronco.
- Referencia de video por revisar: https://www.youtube.com/results?search_query=beginner+dead+bug+exercise

### Equilibrio con apoyo
- Dosificación: 2 × 15–25 segundos por lado; descanso: 30 s.
- Técnica: Mantén postura erguida junto a una silla o pared estable.
- Referencia de video por revisar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise

### Caminata a ritmo cómodo
- Dosificación: 10–20 minutos; descanso: Según necesidad.
- Técnica: Elige un ritmo que permita hablar en frases.
- Referencia de video por revisar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise

### Movilidad suave de cadera y hombros
- Dosificación: 4–6 minutos; descanso: Sin prisa.
- Técnica: Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
- Referencia de video por revisar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner

## Programa día por día

### DÍA 1 — Fuerza y control
**Fase I — Fundamentos · Semana 1 · Entrenamiento · 25 min aprox. · Acceso: free**

**Enfoque:** Aprender movimientos básicos y empezar con seguridad
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Planifica el horario de mañana y deja preparado el espacio de entrenamiento.

**Fe y propósito — Colosenses 3:23:** Haz las cosas de corazón, con intención y propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 2 — Movilidad y hábitos
**Fase I — Fundamentos · Semana 1 · Recuperación activa · 10 min aprox. · Acceso: free**

**Enfoque:** Aprender movimientos básicos y empezar con seguridad
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Bebe agua regularmente, ajustando a clima, actividad y necesidades personales.

**Fe y propósito — Proverbios 16:3:** Organiza tus pasos y encomienda tu trabajo.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 3 — Movimiento y estabilidad
**Fase I — Fundamentos · Semana 1 · Entrenamiento · 25 min aprox. · Acceso: free**

**Enfoque:** Aprender movimientos básicos y empezar con seguridad
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Paso lateral controlado:** 2 × 30–45 segundos; descanso 30 s. Da pasos laterales cortos y controla el regreso, manteniendo las rodillas alineadas.
  - Video por verificar: https://www.youtube.com/results?search_query=lateral+step+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Haz una pausa para caminar o moverte si pasas mucho tiempo sentado.

**Fe y propósito — Isaías 40:31:** La renovación también requiere paciencia.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 4 — Recuperación y gratitud
**Fase I — Fundamentos · Semana 1 · Recuperación activa · 10 min aprox. · Acceso: free**

**Enfoque:** Aprender movimientos básicos y empezar con seguridad
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Prioriza un horario regular para dormir y una rutina tranquila antes de acostarte.

**Fe y propósito — Gálatas 6:9:** Persevera en el bien con equilibrio.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 5 — Fuerza y resistencia
**Fase I — Fundamentos · Semana 1 · Entrenamiento · 25 min aprox. · Acceso: free**

**Enfoque:** Aprender movimientos básicos y empezar con seguridad
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Bisagra de cadera sin carga:** 2 × 8 repeticiones; descanso 45 s. Lleva la cadera atrás con rodillas ligeramente flexionadas y espalda neutral.
  - Video por verificar: https://www.youtube.com/results?search_query=bodyweight+hip+hinge+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Deslizamiento de brazos en pared:** 2 × 8 repeticiones; descanso 30 s. Desliza los brazos por la pared dentro de un rango cómodo sin arquear la zona lumbar.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+slide+shoulder+mobility+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Incluye una comida equilibrada y evita restricciones extremas.

**Fe y propósito — 1 Corintios 6:19–20:** Cuida tu cuerpo con respeto y responsabilidad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 6 — Recuperación y gratitud
**Fase I — Fundamentos · Semana 1 · Recuperación activa · 10 min aprox. · Acceso: free**

**Enfoque:** Aprender movimientos básicos y empezar con seguridad
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Registra tu energía y esfuerzo percibido del 1 al 10.

**Fe y propósito — Filipenses 4:13:** Busca fortaleza para afrontar el proceso con humildad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 7 — Recuperación y gratitud
**Fase I — Fundamentos · Semana 1 · Recuperación activa · 10 min aprox. · Acceso: free**

**Enfoque:** Aprender movimientos básicos y empezar con seguridad
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Agradece algo concreto y reconoce un paso que sí cumpliste.

**Fe y propósito — Salmo 90:17:** Pide dirección para que tu esfuerzo tenga propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 8 — Fuerza y control
**Fase I — Fundamentos · Semana 2 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Mejorar movilidad y control corporal
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Planifica el horario de mañana y deja preparado el espacio de entrenamiento.

**Fe y propósito — Hebreos 12:1:** Avanza con perseverancia, sin compararte con otros.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 9 — Movilidad y hábitos
**Fase I — Fundamentos · Semana 2 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Mejorar movilidad y control corporal
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Bebe agua regularmente, ajustando a clima, actividad y necesidades personales.

**Fe y propósito — Colosenses 3:23:** Haz las cosas de corazón, con intención y propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 10 — Movimiento y estabilidad
**Fase I — Fundamentos · Semana 2 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Mejorar movilidad y control corporal
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Paso lateral controlado:** 2 × 30–45 segundos; descanso 30 s. Da pasos laterales cortos y controla el regreso, manteniendo las rodillas alineadas.
  - Video por verificar: https://www.youtube.com/results?search_query=lateral+step+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Haz una pausa para caminar o moverte si pasas mucho tiempo sentado.

**Fe y propósito — Proverbios 16:3:** Organiza tus pasos y encomienda tu trabajo.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 11 — Recuperación y gratitud
**Fase I — Fundamentos · Semana 2 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Mejorar movilidad y control corporal
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Prioriza un horario regular para dormir y una rutina tranquila antes de acostarte.

**Fe y propósito — Isaías 40:31:** La renovación también requiere paciencia.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 12 — Fuerza y resistencia
**Fase I — Fundamentos · Semana 2 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Mejorar movilidad y control corporal
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Bisagra de cadera sin carga:** 2 × 8 repeticiones; descanso 45 s. Lleva la cadera atrás con rodillas ligeramente flexionadas y espalda neutral.
  - Video por verificar: https://www.youtube.com/results?search_query=bodyweight+hip+hinge+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Deslizamiento de brazos en pared:** 2 × 8 repeticiones; descanso 30 s. Desliza los brazos por la pared dentro de un rango cómodo sin arquear la zona lumbar.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+slide+shoulder+mobility+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Incluye una comida equilibrada y evita restricciones extremas.

**Fe y propósito — Gálatas 6:9:** Persevera en el bien con equilibrio.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 13 — Recuperación y gratitud
**Fase I — Fundamentos · Semana 2 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Mejorar movilidad y control corporal
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Registra tu energía y esfuerzo percibido del 1 al 10.

**Fe y propósito — 1 Corintios 6:19–20:** Cuida tu cuerpo con respeto y responsabilidad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 14 — Recuperación y gratitud
**Fase I — Fundamentos · Semana 2 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Mejorar movilidad y control corporal
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Agradece algo concreto y reconoce un paso que sí cumpliste.

**Fe y propósito — Filipenses 4:13:** Busca fortaleza para afrontar el proceso con humildad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 15 — Fuerza y control
**Fase I — Fundamentos · Semana 3 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Crear constancia y resistencia básica
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Planifica el horario de mañana y deja preparado el espacio de entrenamiento.

**Fe y propósito — Salmo 90:17:** Pide dirección para que tu esfuerzo tenga propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 16 — Movilidad y hábitos
**Fase I — Fundamentos · Semana 3 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Crear constancia y resistencia básica
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Bebe agua regularmente, ajustando a clima, actividad y necesidades personales.

**Fe y propósito — Hebreos 12:1:** Avanza con perseverancia, sin compararte con otros.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 17 — Movimiento y estabilidad
**Fase I — Fundamentos · Semana 3 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Crear constancia y resistencia básica
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Paso lateral controlado:** 2 × 30–45 segundos; descanso 30 s. Da pasos laterales cortos y controla el regreso, manteniendo las rodillas alineadas.
  - Video por verificar: https://www.youtube.com/results?search_query=lateral+step+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Haz una pausa para caminar o moverte si pasas mucho tiempo sentado.

**Fe y propósito — Colosenses 3:23:** Haz las cosas de corazón, con intención y propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 18 — Recuperación y gratitud
**Fase I — Fundamentos · Semana 3 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Crear constancia y resistencia básica
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Prioriza un horario regular para dormir y una rutina tranquila antes de acostarte.

**Fe y propósito — Proverbios 16:3:** Organiza tus pasos y encomienda tu trabajo.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 19 — Fuerza y resistencia
**Fase I — Fundamentos · Semana 3 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Crear constancia y resistencia básica
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Bisagra de cadera sin carga:** 2 × 8 repeticiones; descanso 45 s. Lleva la cadera atrás con rodillas ligeramente flexionadas y espalda neutral.
  - Video por verificar: https://www.youtube.com/results?search_query=bodyweight+hip+hinge+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Deslizamiento de brazos en pared:** 2 × 8 repeticiones; descanso 30 s. Desliza los brazos por la pared dentro de un rango cómodo sin arquear la zona lumbar.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+slide+shoulder+mobility+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Incluye una comida equilibrada y evita restricciones extremas.

**Fe y propósito — Isaías 40:31:** La renovación también requiere paciencia.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 20 — Recuperación y gratitud
**Fase I — Fundamentos · Semana 3 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Crear constancia y resistencia básica
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Registra tu energía y esfuerzo percibido del 1 al 10.

**Fe y propósito — Gálatas 6:9:** Persevera en el bien con equilibrio.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 21 — Recuperación y gratitud
**Fase I — Fundamentos · Semana 3 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Crear constancia y resistencia básica
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Agradece algo concreto y reconoce un paso que sí cumpliste.

**Fe y propósito — 1 Corintios 6:19–20:** Cuida tu cuerpo con respeto y responsabilidad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 22 — Fuerza y control
**Fase I — Fundamentos · Semana 4 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Consolidar fundamentos y revisar hábitos
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Planifica el horario de mañana y deja preparado el espacio de entrenamiento.

**Fe y propósito — Filipenses 4:13:** Busca fortaleza para afrontar el proceso con humildad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 23 — Movilidad y hábitos
**Fase I — Fundamentos · Semana 4 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Consolidar fundamentos y revisar hábitos
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Bebe agua regularmente, ajustando a clima, actividad y necesidades personales.

**Fe y propósito — Salmo 90:17:** Pide dirección para que tu esfuerzo tenga propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 24 — Movimiento y estabilidad
**Fase I — Fundamentos · Semana 4 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Consolidar fundamentos y revisar hábitos
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Paso lateral controlado:** 2 × 30–45 segundos; descanso 30 s. Da pasos laterales cortos y controla el regreso, manteniendo las rodillas alineadas.
  - Video por verificar: https://www.youtube.com/results?search_query=lateral+step+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Haz una pausa para caminar o moverte si pasas mucho tiempo sentado.

**Fe y propósito — Hebreos 12:1:** Avanza con perseverancia, sin compararte con otros.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 25 — Recuperación y gratitud
**Fase I — Fundamentos · Semana 4 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Consolidar fundamentos y revisar hábitos
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Prioriza un horario regular para dormir y una rutina tranquila antes de acostarte.

**Fe y propósito — Colosenses 3:23:** Haz las cosas de corazón, con intención y propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 26 — Fuerza y resistencia
**Fase I — Fundamentos · Semana 4 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Consolidar fundamentos y revisar hábitos
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Bisagra de cadera sin carga:** 2 × 8 repeticiones; descanso 45 s. Lleva la cadera atrás con rodillas ligeramente flexionadas y espalda neutral.
  - Video por verificar: https://www.youtube.com/results?search_query=bodyweight+hip+hinge+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Deslizamiento de brazos en pared:** 2 × 8 repeticiones; descanso 30 s. Desliza los brazos por la pared dentro de un rango cómodo sin arquear la zona lumbar.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+slide+shoulder+mobility+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Incluye una comida equilibrada y evita restricciones extremas.

**Fe y propósito — Proverbios 16:3:** Organiza tus pasos y encomienda tu trabajo.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 27 — Recuperación y gratitud
**Fase I — Fundamentos · Semana 4 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Consolidar fundamentos y revisar hábitos
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Registra tu energía y esfuerzo percibido del 1 al 10.

**Fe y propósito — Isaías 40:31:** La renovación también requiere paciencia.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 28 — Recuperación y gratitud
**Fase I — Fundamentos · Semana 4 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Consolidar fundamentos y revisar hábitos
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Agradece algo concreto y reconoce un paso que sí cumpliste.

**Fe y propósito — Gálatas 6:9:** Persevera en el bien con equilibrio.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 29 — Fuerza y control
**Fase I — Fundamentos · Semana 5 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Desarrollar fuerza general
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Planifica el horario de mañana y deja preparado el espacio de entrenamiento.

**Fe y propósito — 1 Corintios 6:19–20:** Cuida tu cuerpo con respeto y responsabilidad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 30 — Revisión y evaluación de progreso
**Fase I — Fundamentos · Semana 5 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Desarrollar fuerza general
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Bebe agua regularmente, ajustando a clima, actividad y necesidades personales.

**Fe y propósito — Filipenses 4:13:** Busca fortaleza para afrontar el proceso con humildad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 31 — Movimiento y estabilidad
**Fase II — Progreso · Semana 5 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Desarrollar fuerza general
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Paso lateral controlado:** 2 × 30–45 segundos; descanso 30 s. Da pasos laterales cortos y controla el regreso, manteniendo las rodillas alineadas.
  - Video por verificar: https://www.youtube.com/results?search_query=lateral+step+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Haz una pausa para caminar o moverte si pasas mucho tiempo sentado.

**Fe y propósito — Salmo 90:17:** Pide dirección para que tu esfuerzo tenga propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 32 — Recuperación y gratitud
**Fase II — Progreso · Semana 5 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Desarrollar fuerza general
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Prioriza un horario regular para dormir y una rutina tranquila antes de acostarte.

**Fe y propósito — Hebreos 12:1:** Avanza con perseverancia, sin compararte con otros.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 33 — Fuerza y resistencia
**Fase II — Progreso · Semana 5 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Desarrollar fuerza general
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Bisagra de cadera sin carga:** 2 × 8 repeticiones; descanso 45 s. Lleva la cadera atrás con rodillas ligeramente flexionadas y espalda neutral.
  - Video por verificar: https://www.youtube.com/results?search_query=bodyweight+hip+hinge+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Deslizamiento de brazos en pared:** 2 × 8 repeticiones; descanso 30 s. Desliza los brazos por la pared dentro de un rango cómodo sin arquear la zona lumbar.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+slide+shoulder+mobility+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Incluye una comida equilibrada y evita restricciones extremas.

**Fe y propósito — Colosenses 3:23:** Haz las cosas de corazón, con intención y propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 34 — Recuperación y gratitud
**Fase II — Progreso · Semana 5 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Desarrollar fuerza general
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Registra tu energía y esfuerzo percibido del 1 al 10.

**Fe y propósito — Proverbios 16:3:** Organiza tus pasos y encomienda tu trabajo.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 35 — Recuperación y gratitud
**Fase II — Progreso · Semana 5 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Desarrollar fuerza general
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Agradece algo concreto y reconoce un paso que sí cumpliste.

**Fe y propósito — Isaías 40:31:** La renovación también requiere paciencia.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 36 — Fuerza y control
**Fase II — Progreso · Semana 6 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Mejorar resistencia cardiovascular
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Planifica el horario de mañana y deja preparado el espacio de entrenamiento.

**Fe y propósito — Gálatas 6:9:** Persevera en el bien con equilibrio.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 37 — Movilidad y hábitos
**Fase II — Progreso · Semana 6 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Mejorar resistencia cardiovascular
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Bebe agua regularmente, ajustando a clima, actividad y necesidades personales.

**Fe y propósito — 1 Corintios 6:19–20:** Cuida tu cuerpo con respeto y responsabilidad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 38 — Movimiento y estabilidad
**Fase II — Progreso · Semana 6 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Mejorar resistencia cardiovascular
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Paso lateral controlado:** 2 × 30–45 segundos; descanso 30 s. Da pasos laterales cortos y controla el regreso, manteniendo las rodillas alineadas.
  - Video por verificar: https://www.youtube.com/results?search_query=lateral+step+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Haz una pausa para caminar o moverte si pasas mucho tiempo sentado.

**Fe y propósito — Filipenses 4:13:** Busca fortaleza para afrontar el proceso con humildad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 39 — Recuperación y gratitud
**Fase II — Progreso · Semana 6 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Mejorar resistencia cardiovascular
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Prioriza un horario regular para dormir y una rutina tranquila antes de acostarte.

**Fe y propósito — Salmo 90:17:** Pide dirección para que tu esfuerzo tenga propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 40 — Fuerza y resistencia
**Fase II — Progreso · Semana 6 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Mejorar resistencia cardiovascular
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Bisagra de cadera sin carga:** 2 × 8 repeticiones; descanso 45 s. Lleva la cadera atrás con rodillas ligeramente flexionadas y espalda neutral.
  - Video por verificar: https://www.youtube.com/results?search_query=bodyweight+hip+hinge+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Deslizamiento de brazos en pared:** 2 × 8 repeticiones; descanso 30 s. Desliza los brazos por la pared dentro de un rango cómodo sin arquear la zona lumbar.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+slide+shoulder+mobility+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Incluye una comida equilibrada y evita restricciones extremas.

**Fe y propósito — Hebreos 12:1:** Avanza con perseverancia, sin compararte con otros.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 41 — Recuperación y gratitud
**Fase II — Progreso · Semana 6 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Mejorar resistencia cardiovascular
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Registra tu energía y esfuerzo percibido del 1 al 10.

**Fe y propósito — Colosenses 3:23:** Haz las cosas de corazón, con intención y propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 42 — Recuperación y gratitud
**Fase II — Progreso · Semana 6 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Mejorar resistencia cardiovascular
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Agradece algo concreto y reconoce un paso que sí cumpliste.

**Fe y propósito — Proverbios 16:3:** Organiza tus pasos y encomienda tu trabajo.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 43 — Fuerza y control
**Fase II — Progreso · Semana 7 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Equilibrio, coordinación y core
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Planifica el horario de mañana y deja preparado el espacio de entrenamiento.

**Fe y propósito — Isaías 40:31:** La renovación también requiere paciencia.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 44 — Movilidad y hábitos
**Fase II — Progreso · Semana 7 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Equilibrio, coordinación y core
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Bebe agua regularmente, ajustando a clima, actividad y necesidades personales.

**Fe y propósito — Gálatas 6:9:** Persevera en el bien con equilibrio.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 45 — Movimiento y estabilidad
**Fase II — Progreso · Semana 7 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Equilibrio, coordinación y core
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Paso lateral controlado:** 2 × 30–45 segundos; descanso 30 s. Da pasos laterales cortos y controla el regreso, manteniendo las rodillas alineadas.
  - Video por verificar: https://www.youtube.com/results?search_query=lateral+step+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Haz una pausa para caminar o moverte si pasas mucho tiempo sentado.

**Fe y propósito — 1 Corintios 6:19–20:** Cuida tu cuerpo con respeto y responsabilidad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 46 — Recuperación y gratitud
**Fase II — Progreso · Semana 7 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Equilibrio, coordinación y core
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Prioriza un horario regular para dormir y una rutina tranquila antes de acostarte.

**Fe y propósito — Filipenses 4:13:** Busca fortaleza para afrontar el proceso con humildad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 47 — Fuerza y resistencia
**Fase II — Progreso · Semana 7 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Equilibrio, coordinación y core
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Bisagra de cadera sin carga:** 2 × 8 repeticiones; descanso 45 s. Lleva la cadera atrás con rodillas ligeramente flexionadas y espalda neutral.
  - Video por verificar: https://www.youtube.com/results?search_query=bodyweight+hip+hinge+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Deslizamiento de brazos en pared:** 2 × 8 repeticiones; descanso 30 s. Desliza los brazos por la pared dentro de un rango cómodo sin arquear la zona lumbar.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+slide+shoulder+mobility+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Incluye una comida equilibrada y evita restricciones extremas.

**Fe y propósito — Salmo 90:17:** Pide dirección para que tu esfuerzo tenga propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 48 — Recuperación y gratitud
**Fase II — Progreso · Semana 7 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Equilibrio, coordinación y core
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Registra tu energía y esfuerzo percibido del 1 al 10.

**Fe y propósito — Hebreos 12:1:** Avanza con perseverancia, sin compararte con otros.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 49 — Recuperación y gratitud
**Fase II — Progreso · Semana 7 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Equilibrio, coordinación y core
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Agradece algo concreto y reconoce un paso que sí cumpliste.

**Fe y propósito — Colosenses 3:23:** Haz las cosas de corazón, con intención y propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 50 — Fuerza y control
**Fase II — Progreso · Semana 8 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Integrar fuerza y cardio
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Planifica el horario de mañana y deja preparado el espacio de entrenamiento.

**Fe y propósito — Proverbios 16:3:** Organiza tus pasos y encomienda tu trabajo.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 51 — Movilidad y hábitos
**Fase II — Progreso · Semana 8 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Integrar fuerza y cardio
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Bebe agua regularmente, ajustando a clima, actividad y necesidades personales.

**Fe y propósito — Isaías 40:31:** La renovación también requiere paciencia.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 52 — Movimiento y estabilidad
**Fase II — Progreso · Semana 8 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Integrar fuerza y cardio
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Paso lateral controlado:** 2 × 30–45 segundos; descanso 30 s. Da pasos laterales cortos y controla el regreso, manteniendo las rodillas alineadas.
  - Video por verificar: https://www.youtube.com/results?search_query=lateral+step+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Haz una pausa para caminar o moverte si pasas mucho tiempo sentado.

**Fe y propósito — Gálatas 6:9:** Persevera en el bien con equilibrio.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 53 — Recuperación y gratitud
**Fase II — Progreso · Semana 8 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Integrar fuerza y cardio
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Prioriza un horario regular para dormir y una rutina tranquila antes de acostarte.

**Fe y propósito — 1 Corintios 6:19–20:** Cuida tu cuerpo con respeto y responsabilidad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 54 — Fuerza y resistencia
**Fase II — Progreso · Semana 8 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Integrar fuerza y cardio
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Bisagra de cadera sin carga:** 2 × 8 repeticiones; descanso 45 s. Lleva la cadera atrás con rodillas ligeramente flexionadas y espalda neutral.
  - Video por verificar: https://www.youtube.com/results?search_query=bodyweight+hip+hinge+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Deslizamiento de brazos en pared:** 2 × 8 repeticiones; descanso 30 s. Desliza los brazos por la pared dentro de un rango cómodo sin arquear la zona lumbar.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+slide+shoulder+mobility+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Incluye una comida equilibrada y evita restricciones extremas.

**Fe y propósito — Filipenses 4:13:** Busca fortaleza para afrontar el proceso con humildad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 55 — Recuperación y gratitud
**Fase II — Progreso · Semana 8 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Integrar fuerza y cardio
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Registra tu energía y esfuerzo percibido del 1 al 10.

**Fe y propósito — Salmo 90:17:** Pide dirección para que tu esfuerzo tenga propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 56 — Recuperación y gratitud
**Fase II — Progreso · Semana 8 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Integrar fuerza y cardio
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Agradece algo concreto y reconoce un paso que sí cumpliste.

**Fe y propósito — Hebreos 12:1:** Avanza con perseverancia, sin compararte con otros.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 57 — Fuerza y control
**Fase II — Progreso · Semana 9 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Mejorar control y calidad del movimiento
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Planifica el horario de mañana y deja preparado el espacio de entrenamiento.

**Fe y propósito — Colosenses 3:23:** Haz las cosas de corazón, con intención y propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 58 — Movilidad y hábitos
**Fase II — Progreso · Semana 9 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Mejorar control y calidad del movimiento
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Bebe agua regularmente, ajustando a clima, actividad y necesidades personales.

**Fe y propósito — Proverbios 16:3:** Organiza tus pasos y encomienda tu trabajo.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 59 — Movimiento y estabilidad
**Fase II — Progreso · Semana 9 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Mejorar control y calidad del movimiento
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Paso lateral controlado:** 2 × 30–45 segundos; descanso 30 s. Da pasos laterales cortos y controla el regreso, manteniendo las rodillas alineadas.
  - Video por verificar: https://www.youtube.com/results?search_query=lateral+step+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Haz una pausa para caminar o moverte si pasas mucho tiempo sentado.

**Fe y propósito — Isaías 40:31:** La renovación también requiere paciencia.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 60 — Revisión y evaluación de progreso
**Fase II — Progreso · Semana 9 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Mejorar control y calidad del movimiento
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Prioriza un horario regular para dormir y una rutina tranquila antes de acostarte.

**Fe y propósito — Gálatas 6:9:** Persevera en el bien con equilibrio.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 61 — Fuerza y resistencia
**Fase III — Consolidación · Semana 9 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Mejorar control y calidad del movimiento
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Bisagra de cadera sin carga:** 2 × 8 repeticiones; descanso 45 s. Lleva la cadera atrás con rodillas ligeramente flexionadas y espalda neutral.
  - Video por verificar: https://www.youtube.com/results?search_query=bodyweight+hip+hinge+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Deslizamiento de brazos en pared:** 2 × 8 repeticiones; descanso 30 s. Desliza los brazos por la pared dentro de un rango cómodo sin arquear la zona lumbar.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+slide+shoulder+mobility+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Incluye una comida equilibrada y evita restricciones extremas.

**Fe y propósito — 1 Corintios 6:19–20:** Cuida tu cuerpo con respeto y responsabilidad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 62 — Recuperación y gratitud
**Fase III — Consolidación · Semana 9 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Mejorar control y calidad del movimiento
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Registra tu energía y esfuerzo percibido del 1 al 10.

**Fe y propósito — Filipenses 4:13:** Busca fortaleza para afrontar el proceso con humildad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 63 — Recuperación y gratitud
**Fase III — Consolidación · Semana 9 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Mejorar control y calidad del movimiento
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Agradece algo concreto y reconoce un paso que sí cumpliste.

**Fe y propósito — Salmo 90:17:** Pide dirección para que tu esfuerzo tenga propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 64 — Fuerza y control
**Fase III — Consolidación · Semana 10 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Progresar de forma responsable
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Planifica el horario de mañana y deja preparado el espacio de entrenamiento.

**Fe y propósito — Hebreos 12:1:** Avanza con perseverancia, sin compararte con otros.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 65 — Movilidad y hábitos
**Fase III — Consolidación · Semana 10 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Progresar de forma responsable
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Bebe agua regularmente, ajustando a clima, actividad y necesidades personales.

**Fe y propósito — Colosenses 3:23:** Haz las cosas de corazón, con intención y propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 66 — Movimiento y estabilidad
**Fase III — Consolidación · Semana 10 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Progresar de forma responsable
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Paso lateral controlado:** 2 × 30–45 segundos; descanso 30 s. Da pasos laterales cortos y controla el regreso, manteniendo las rodillas alineadas.
  - Video por verificar: https://www.youtube.com/results?search_query=lateral+step+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Haz una pausa para caminar o moverte si pasas mucho tiempo sentado.

**Fe y propósito — Proverbios 16:3:** Organiza tus pasos y encomienda tu trabajo.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 67 — Recuperación y gratitud
**Fase III — Consolidación · Semana 10 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Progresar de forma responsable
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Prioriza un horario regular para dormir y una rutina tranquila antes de acostarte.

**Fe y propósito — Isaías 40:31:** La renovación también requiere paciencia.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 68 — Fuerza y resistencia
**Fase III — Consolidación · Semana 10 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Progresar de forma responsable
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Bisagra de cadera sin carga:** 2 × 8 repeticiones; descanso 45 s. Lleva la cadera atrás con rodillas ligeramente flexionadas y espalda neutral.
  - Video por verificar: https://www.youtube.com/results?search_query=bodyweight+hip+hinge+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Deslizamiento de brazos en pared:** 2 × 8 repeticiones; descanso 30 s. Desliza los brazos por la pared dentro de un rango cómodo sin arquear la zona lumbar.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+slide+shoulder+mobility+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Incluye una comida equilibrada y evita restricciones extremas.

**Fe y propósito — Gálatas 6:9:** Persevera en el bien con equilibrio.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 69 — Recuperación y gratitud
**Fase III — Consolidación · Semana 10 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Progresar de forma responsable
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Registra tu energía y esfuerzo percibido del 1 al 10.

**Fe y propósito — 1 Corintios 6:19–20:** Cuida tu cuerpo con respeto y responsabilidad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 70 — Recuperación y gratitud
**Fase III — Consolidación · Semana 10 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Progresar de forma responsable
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Agradece algo concreto y reconoce un paso que sí cumpliste.

**Fe y propósito — Filipenses 4:13:** Busca fortaleza para afrontar el proceso con humildad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 71 — Fuerza y control
**Fase III — Consolidación · Semana 11 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Ganar autonomía y recuperar mejor
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Planifica el horario de mañana y deja preparado el espacio de entrenamiento.

**Fe y propósito — Salmo 90:17:** Pide dirección para que tu esfuerzo tenga propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 72 — Movilidad y hábitos
**Fase III — Consolidación · Semana 11 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Ganar autonomía y recuperar mejor
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Bebe agua regularmente, ajustando a clima, actividad y necesidades personales.

**Fe y propósito — Hebreos 12:1:** Avanza con perseverancia, sin compararte con otros.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 73 — Movimiento y estabilidad
**Fase III — Consolidación · Semana 11 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Ganar autonomía y recuperar mejor
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Paso lateral controlado:** 2 × 30–45 segundos; descanso 30 s. Da pasos laterales cortos y controla el regreso, manteniendo las rodillas alineadas.
  - Video por verificar: https://www.youtube.com/results?search_query=lateral+step+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Haz una pausa para caminar o moverte si pasas mucho tiempo sentado.

**Fe y propósito — Colosenses 3:23:** Haz las cosas de corazón, con intención y propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 74 — Recuperación y gratitud
**Fase III — Consolidación · Semana 11 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Ganar autonomía y recuperar mejor
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Prioriza un horario regular para dormir y una rutina tranquila antes de acostarte.

**Fe y propósito — Proverbios 16:3:** Organiza tus pasos y encomienda tu trabajo.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 75 — Fuerza y resistencia
**Fase III — Consolidación · Semana 11 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Ganar autonomía y recuperar mejor
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Bisagra de cadera sin carga:** 2 × 8 repeticiones; descanso 45 s. Lleva la cadera atrás con rodillas ligeramente flexionadas y espalda neutral.
  - Video por verificar: https://www.youtube.com/results?search_query=bodyweight+hip+hinge+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Deslizamiento de brazos en pared:** 2 × 8 repeticiones; descanso 30 s. Desliza los brazos por la pared dentro de un rango cómodo sin arquear la zona lumbar.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+slide+shoulder+mobility+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Incluye una comida equilibrada y evita restricciones extremas.

**Fe y propósito — Isaías 40:31:** La renovación también requiere paciencia.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 76 — Recuperación y gratitud
**Fase III — Consolidación · Semana 11 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Ganar autonomía y recuperar mejor
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Registra tu energía y esfuerzo percibido del 1 al 10.

**Fe y propósito — Gálatas 6:9:** Persevera en el bien con equilibrio.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 77 — Recuperación y gratitud
**Fase III — Consolidación · Semana 11 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Ganar autonomía y recuperar mejor
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Agradece algo concreto y reconoce un paso que sí cumpliste.

**Fe y propósito — 1 Corintios 6:19–20:** Cuida tu cuerpo con respeto y responsabilidad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 78 — Fuerza y control
**Fase III — Consolidación · Semana 12 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Consolidar hábitos a largo plazo
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Planifica el horario de mañana y deja preparado el espacio de entrenamiento.

**Fe y propósito — Filipenses 4:13:** Busca fortaleza para afrontar el proceso con humildad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 79 — Movilidad y hábitos
**Fase III — Consolidación · Semana 12 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Consolidar hábitos a largo plazo
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Bebe agua regularmente, ajustando a clima, actividad y necesidades personales.

**Fe y propósito — Salmo 90:17:** Pide dirección para que tu esfuerzo tenga propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 80 — Movimiento y estabilidad
**Fase III — Consolidación · Semana 12 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Consolidar hábitos a largo plazo
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Paso lateral controlado:** 2 × 30–45 segundos; descanso 30 s. Da pasos laterales cortos y controla el regreso, manteniendo las rodillas alineadas.
  - Video por verificar: https://www.youtube.com/results?search_query=lateral+step+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Haz una pausa para caminar o moverte si pasas mucho tiempo sentado.

**Fe y propósito — Hebreos 12:1:** Avanza con perseverancia, sin compararte con otros.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 81 — Recuperación y gratitud
**Fase III — Consolidación · Semana 12 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Consolidar hábitos a largo plazo
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Prioriza un horario regular para dormir y una rutina tranquila antes de acostarte.

**Fe y propósito — Colosenses 3:23:** Haz las cosas de corazón, con intención y propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 82 — Fuerza y resistencia
**Fase III — Consolidación · Semana 12 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Consolidar hábitos a largo plazo
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Bisagra de cadera sin carga:** 2 × 8 repeticiones; descanso 45 s. Lleva la cadera atrás con rodillas ligeramente flexionadas y espalda neutral.
  - Video por verificar: https://www.youtube.com/results?search_query=bodyweight+hip+hinge+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Deslizamiento de brazos en pared:** 2 × 8 repeticiones; descanso 30 s. Desliza los brazos por la pared dentro de un rango cómodo sin arquear la zona lumbar.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+slide+shoulder+mobility+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Incluye una comida equilibrada y evita restricciones extremas.

**Fe y propósito — Proverbios 16:3:** Organiza tus pasos y encomienda tu trabajo.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 83 — Recuperación y gratitud
**Fase III — Consolidación · Semana 12 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Consolidar hábitos a largo plazo
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Registra tu energía y esfuerzo percibido del 1 al 10.

**Fe y propósito — Isaías 40:31:** La renovación también requiere paciencia.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 84 — Recuperación y gratitud
**Fase III — Consolidación · Semana 12 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Consolidar hábitos a largo plazo
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Agradece algo concreto y reconoce un paso que sí cumpliste.

**Fe y propósito — Gálatas 6:9:** Persevera en el bien con equilibrio.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 85 — Fuerza y control
**Fase III — Consolidación · Semana 13 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Evaluar progreso y preparar continuidad
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Planifica el horario de mañana y deja preparado el espacio de entrenamiento.

**Fe y propósito — 1 Corintios 6:19–20:** Cuida tu cuerpo con respeto y responsabilidad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 86 — Movilidad y hábitos
**Fase III — Consolidación · Semana 13 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Evaluar progreso y preparar continuidad
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Bebe agua regularmente, ajustando a clima, actividad y necesidades personales.

**Fe y propósito — Filipenses 4:13:** Busca fortaleza para afrontar el proceso con humildad.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 87 — Movimiento y estabilidad
**Fase III — Consolidación · Semana 13 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Evaluar progreso y preparar continuidad
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Sentarse y levantarse de una silla:** 2 × 6–10 repeticiones; descanso 45–60 s. Pies firmes; inclina ligeramente el tronco y levántate con control. Usa las manos si hace falta.
  - Video por verificar: https://www.youtube.com/results?search_query=sit+to+stand+chair+exercise+demonstration
  - Imagen demostrativa pendiente de producir o licenciar.
- **Paso lateral controlado:** 2 × 30–45 segundos; descanso 30 s. Da pasos laterales cortos y controla el regreso, manteniendo las rodillas alineadas.
  - Video por verificar: https://www.youtube.com/results?search_query=lateral+step+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Flexiones contra la pared:** 2 × 6–10 repeticiones; descanso 45–60 s. Manos a la altura del pecho, cuerpo alineado; acerca el pecho a la pared y empuja con control.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+push+up+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Haz una pausa para caminar o moverte si pasas mucho tiempo sentado.

**Fe y propósito — Salmo 90:17:** Pide dirección para que tu esfuerzo tenga propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 88 — Recuperación y gratitud
**Fase III — Consolidación · Semana 13 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Evaluar progreso y preparar continuidad
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.
- **Equilibrio con apoyo:** 2 × 15–25 segundos por lado; descanso 30 s. Mantén postura erguida junto a una silla o pared estable.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+single+leg+balance+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Prioriza un horario regular para dormir y una rutina tranquila antes de acostarte.

**Fe y propósito — Hebreos 12:1:** Avanza con perseverancia, sin compararte con otros.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 89 — Fuerza y resistencia
**Fase III — Consolidación · Semana 13 · Entrenamiento · 25 min aprox. · Acceso: premium**

**Enfoque:** Evaluar progreso y preparar continuidad
**Calentamiento:** Marcha suave: 2 minutos; Movilidad cómoda de hombros y cadera: 2–3 minutos
- **Bisagra de cadera sin carga:** 2 × 8 repeticiones; descanso 45 s. Lleva la cadera atrás con rodillas ligeramente flexionadas y espalda neutral.
  - Video por verificar: https://www.youtube.com/results?search_query=bodyweight+hip+hinge+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Elevaciones de talones con apoyo:** 2 × 8–12 repeticiones; descanso 30–45 s. Sujétate de una silla firme, eleva los talones y baja lentamente.
  - Video por verificar: https://www.youtube.com/results?search_query=supported+standing+calf+raise+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Bird-dog alternado:** 2 × 5–8 por lado; descanso 45 s. En cuatro apoyos, extiende brazo y pierna contrarios sin girar la pelvis.
  - Video por verificar: https://www.youtube.com/results?search_query=bird+dog+exercise+proper+form
  - Imagen demostrativa pendiente de producir o licenciar.
- **Deslizamiento de brazos en pared:** 2 × 8 repeticiones; descanso 30 s. Desliza los brazos por la pared dentro de un rango cómodo sin arquear la zona lumbar.
  - Video por verificar: https://www.youtube.com/results?search_query=wall+slide+shoulder+mobility+exercise
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Incluye una comida equilibrada y evita restricciones extremas.

**Fe y propósito — Colosenses 3:23:** Haz las cosas de corazón, con intención y propósito.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

### DÍA 90 — Revisión y evaluación de progreso
**Fase III — Consolidación · Semana 13 · Recuperación activa · 10 min aprox. · Acceso: premium**

**Enfoque:** Evaluar progreso y preparar continuidad
- **Caminata a ritmo cómodo:** 10–20 minutos; descanso Según necesidad. Elige un ritmo que permita hablar en frases.
  - Video por verificar: https://www.youtube.com/results?search_query=beginner+walking+posture+exercise
  - Imagen demostrativa pendiente de producir o licenciar.
- **Movilidad suave de cadera y hombros:** 4–6 minutos; descanso Sin prisa. Realiza movimientos lentos, sin rebotes y dentro de un rango cómodo.
  - Video por verificar: https://www.youtube.com/results?search_query=gentle+hip+shoulder+mobility+routine+beginner
  - Imagen demostrativa pendiente de producir o licenciar.

**Hábito:** Registra tu energía y esfuerzo percibido del 1 al 10.

**Fe y propósito — Proverbios 16:3:** Organiza tus pasos y encomienda tu trabajo.

**Registro:** ¿Qué paso concreto pude cumplir hoy y qué ajustaré mañana?

**Seguridad:** Detén la actividad ante dolor agudo, mareo, dolor torácico o falta de aire inusual. Si tienes una lesión o condición médica, consulta a un profesional antes de comenzar.

## Pendientes antes de vender
- Revisión profesional del plan completo.
- Crear/seleccionar imágenes con derechos comerciales adecuados.
- Verificar videos individualmente; los enlaces actuales son búsquedas, no videos validados.
- Implementar verificación segura del pago y permiso Premium.
- Publicar términos, privacidad, reembolsos y soporte.
- Probar registro, progreso y desbloqueo en móvil.
